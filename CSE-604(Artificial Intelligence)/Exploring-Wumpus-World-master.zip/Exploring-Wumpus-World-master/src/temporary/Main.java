package temporary;
public class Main {

	public static void main(String[] args) {
//		new GameUpdated();
//		boolean b11 = true;
//		boolean b12 = true;
//		boolean p13 = true;
//		boolean p22 = true;
//		boolean p11 = true;
//		boolean p12 = true;
//		boolean p21 = true;
//		
//		boolean alpha = true;
//		
//		boolean a = (!b12) | p13 | p22;
//		boolean x = (!p13) | b12;
//		boolean y = (!p22) | b12;
//
//		boolean resolution = a & x & y & (!b12) & (!p11) & (!p12) & (!p21) & alpha;
//
//		System.out.println(resolution);

	}

}
