package rmi_client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import rmi_server.Person;

public class Client {
	public static void main(String[] args) 
    {
		 ObjectInputStream oin = null;
	     ServerSocket server;
	     Socket socket = null;
	     InputStream in = null;
	     FileOutputStream out = null;
        System.out.println("Connecting to Server ...");
        try 
        {
        	socket = new Socket("192.168.0.103", 1406);
        	in = socket.getInputStream();
            out = new FileOutputStream("test2.ser");
            
            byte[] bytes = new byte[16*1024];

            int count;
            while ((count = in.read(bytes)) > 0) {
                out.write(bytes, 0, count);
            }
            FileInputStream file = new FileInputStream("test2.ser"); 
            ObjectInputStream in2 = new ObjectInputStream(file); 
            
            
            // Method for deserialization of object 
            Person object1 = (Person)in2.readObject();
            System.out.println("Object has been received and calling remote method: "+object1.add(10, 10));
            
            /* System.out.println("Client Connected..Sending ArrayList to Client");
            ObjectInputStream oin = new ObjectInputStream(socket.getInputStream());
            ArrayList<Person> list = (ArrayList<Person>)oin.readObject();
            System.out.println("Recieved ArrayList from client "+list);    
            for(AdditionInterface addinter:list) {
            	
            	addinter.add(10,10);
            }*/
            
           

        } catch ( Exception e) 
        {
            e.printStackTrace();
        }
        finally
        {
            if (out!= null)
            {
                try
                {
                    out.close();
                }
                catch (Exception ex){}
            }
            if (socket != null)
            {
                try
                {
                	socket.close();
                }
                catch (Exception ex){}
            }
        }
    
}


}
