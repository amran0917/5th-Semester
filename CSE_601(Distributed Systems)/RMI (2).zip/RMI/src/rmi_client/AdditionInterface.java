package rmi_client;

import java.io.Serializable;

public interface AdditionInterface extends Serializable{

	public abstract int add(int a,int b);
}
