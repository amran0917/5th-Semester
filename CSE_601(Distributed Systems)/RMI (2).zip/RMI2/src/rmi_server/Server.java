package rmi_server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {

	public static void main(String[] args) 
    {
        ObjectInputStream oin = null;
        ServerSocket server;
        Socket socket = null;
        InputStream in = null;
        ObjectOutputStream out = null;
        System.out.println("Connecting to Client ...");
        try
        {
            server = new ServerSocket(1406);
            socket = server.accept();
            FileOutputStream fileoutstream = new FileOutputStream("test1.ser"); 
            out = new ObjectOutputStream(fileoutstream); 
              
            // Method for serialization of object 
            AdditionInterface add=new Person("azaz",10);
            out.writeObject(add); 
            
            //serialize object writing to file
            File file = new File("test1.ser");
            long length = file.length();
            byte[] bytes = new byte[16 * 1024];
            in = new FileInputStream(file);
            OutputStream out2 = socket.getOutputStream();

            int count;
            while ((count = in.read(bytes)) > 0) {
                out2.write(bytes, 0, count);
            }
            
            
           
           // System.out.println("Recieved ArrayList from client "+list);       
            //Writing to file now 
           /* FileOutputStream fos = new FileOutputStream("Filename.ser");
            ObjectOutputStream out = new ObjectOutputStream(fos);
            out.write(list);
            fos.close();
            out.close();
            System.out.println("Written to file");*/
            
            //object serialization
            /*ObjectOutputStream out = new ObjectOutputStream (s.getOutputStream());
            AdditionInterface add=new Person("azaz",10);
            out.writeObject(add);
            out.flush();*/
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (oin != null)
            {
                try
                {
                    oin.close();
                }
                catch (Exception ex){}
            }
            if (socket != null)
            {
                try
                {
                    socket.close();
                }
                catch (Exception ex){}
            }
        }
    }
}
