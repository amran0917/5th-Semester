package rmi_server;

import java.io.Serializable;

public class Person  implements AdditionInterface {
	private String name;
	private int roll;
	
	public Person(String name,int roll) {
		
		this.name=name;
		this.roll=roll;
		
	}

	@Override
	public int add(int a, int b) {
		
		return a+b;
	}

}
