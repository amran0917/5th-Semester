package server_rmi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {

	public static void main(String[] args) 
    {
        ObjectInputStream oin = null;
        ServerSocket server;
        Socket socket = null;
        InputStream in = null;
        ObjectOutputStream out = null;
        System.out.println("Now Connecting to the available client!!");
        try
        {
            server = new ServerSocket(1414);
            socket = server.accept();
            FileOutputStream fileoutstream = new FileOutputStream("my.ser"); 
            out = new ObjectOutputStream(fileoutstream); 
              
            // Method for serialization of object 
            Multiplication mult=new Teacher("KKG",50);
            out.writeObject(mult); 
            
            //serialize object writing to file
            File file = new File("my.ser");
            long length = file.length();
            byte[] bytes = new byte[16 * 1024];
            in = new FileInputStream(file);
            OutputStream out2 = socket.getOutputStream();

            int count;
            while ((count = in.read(bytes)) > 0) {
                out2.write(bytes, 0, count);
            }
            
        
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (oin != null)
            {
                try
                {
                    oin.close();
                }
                catch (Exception ex){}
            }
            if (socket != null)
            {
                try
                {
                    socket.close();
                }
                catch (Exception ex){}
            }
        }
    }
}
