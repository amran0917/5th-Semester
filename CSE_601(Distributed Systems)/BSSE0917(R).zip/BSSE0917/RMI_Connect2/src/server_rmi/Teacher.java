package server_rmi;

import java.io.Serializable;

public class Teacher  implements Multiplication {
	private String name;
	private int id;
	
	public Teacher(String name,int id) {
		
		this.name=name;
		this.id=id;
		
	}

	@Override
	public int mult(int n1, int n2) {
		int car = n1*n2;
		
		return car;
	}

}
