package client;

import java.io.Serializable;

public interface Multiplication  extends Serializable{

	public abstract int mult(int n1,int n2);
}
