package client;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import server_rmi.Teacher;

public class Client {
	public static void main(String[] args) 
    {
		 ObjectInputStream os = null;
	     ServerSocket server;
	     Socket socket = null;
	     InputStream in = null;
	     FileOutputStream out = null;
        System.out.println("Connecting to Server???");
        try 
        {
        	socket = new Socket("localhost", 1414);
        	in = socket.getInputStream();
            out = new FileOutputStream("his.ser");
            
            byte[] bytes = new byte[16384];

            int count;
            while ((count = in.read(bytes)) > 0) {
                out.write(bytes, 0, count);
            }
            FileInputStream file = new FileInputStream("his.ser"); 
            ObjectInputStream in2 = new ObjectInputStream(file); 
            
            
            // Method for deserialization of object 
            Teacher tea = (Teacher)in2.readObject();
            System.out.println("Object has been received.\n and calling the remote object: "+tea.mult(50, 50));
            
           
           

        } catch ( Exception e) 
        {
            e.printStackTrace();
        }
        finally
        {
            if (out!= null)
            {
                try
                {
                    out.close();
                }
                catch (Exception ex){}
            }
            if (socket != null)
            {
                try
                {
                	socket.close();
                }
                catch (Exception ex){}
            }
        }
    
}


}
