package atiq;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.AssertStatement;
import org.eclipse.jdt.core.dom.CompilationUnit;import org.eclipse.jdt.core.dom.MethodDeclaration;

import ast_maker.MyASTVisitor;

public class Test {
	public static void main(String [] args) {
		String filepath = "/home/iit/Desktop/LoadJson.java";
		String content = readLineByLineJava8(filepath);

		ASTParser parser = ASTParser.newParser(AST.JLS3);
		parser.setSource(content.toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);

		MyASTVisitor visitor = new MyASTVisitor();
		
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		
		cu.accept(new ASTVisitor() {
			@Override
			public boolean visit(AssertStatement node) {
				// TODO Auto-generated method stub
				return super.visit(node);
			}
			
			@Override
			public boolean visit(MethodDeclaration node) {
				// TODO Auto-generated method stub
				if(node.getName().toString().equals("saveJson")) {
					System.out.println("found");
				}
				return super.visit(node);
			}
		});
	}
	private static String readLineByLineJava8(String filePath)
	{
	    StringBuilder contentBuilder = new StringBuilder();
	    try (Stream<String> stream = Files.lines( Paths.get(filePath), StandardCharsets.UTF_8))
	    {
	        stream.forEach(s -> contentBuilder.append(s).append("\n"));
	    }
	    catch (IOException e)
	    {
	        e.printStackTrace();
	    }
	    return contentBuilder.toString();
	}
}
