package cbo;

public class Coupling2 extends D implements CInterface {

	public void m1(A a, B b) {
	}
	
	public C m2() {
		return null;
	}
}
