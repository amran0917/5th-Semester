package cbo;

public class Coupling4 {

	public void m1() {
		new A();
		new B();
		new C();
	}
}
