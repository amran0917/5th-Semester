package methods;

public class Methods {
	
	private int a() {}
	private String b() {}
	public double c() {}
	private static String d() {}
	public static int e() {}
	protected double energy() {}
	protected static int cc9(){}
	private String name()
	{
		System.out.println("YOur name is omuk");
	}
	
}