package fields;

public class Fields {
	
	private int a;
	private String b;
	public double c;
	private static String d;
	public static int e;
	
}