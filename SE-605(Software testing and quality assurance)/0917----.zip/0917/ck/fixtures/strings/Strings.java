package strings;

class Strings {
	
	public void m1() {
		String a1 = "Mau";

		String b1 = "Ammar";
	}

	public void m2() {
		System.out.println("amader" + "Desh"+"Name");
	}

	public void m3() {
		
	}
}