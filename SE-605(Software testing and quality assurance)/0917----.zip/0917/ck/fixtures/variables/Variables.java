package variables;

class Variables {
	
	public void m1() {
		int a;
		int b;
		String c;
		OtherClass d;
	}

	public void m2() {
		double e = 10.0;
		int f, h;
		int g = 10;
		
	}

	public void m3() {
		char ch;
	}
}