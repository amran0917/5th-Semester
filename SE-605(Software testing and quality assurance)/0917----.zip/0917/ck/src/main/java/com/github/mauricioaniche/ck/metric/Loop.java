package com.github.mauricioaniche.ck.metric;

class Loop {
	
	int countdo=1;
	
	public void m1() {
		int total = 10;
		for(int i = 0; i < 10; i++) {
			total *= i;
		}
		
		for(int j=0;j<5;j++)
		{
			System.out.println("Kamm kore naa");
		}
	}

	public void m2() {
		int total = 10;
		int i = 0;
		while(i == 0) {
			total *= i;
		}

		while(i == 0) {
			total *= i + 2;
		}
	}

	public int m3() {
		int total = 10;
		int i = 0;
		do {
			countdo++;
			total *= i;
		} while(i == 0);
		
		return countdo;
	}

	public void m4() {

	}

	public void m5() {
		int[] numbers = new int[] { 1, 2, 3, 4};

		for(int n : numbers) {
			System.out.println(n);
		}
	}
}