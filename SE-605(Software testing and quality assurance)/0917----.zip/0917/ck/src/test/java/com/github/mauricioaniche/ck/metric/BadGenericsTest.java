package com.github.mauricioaniche.ck.metric;

import com.github.mauricioaniche.ck.CKClassResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

import java.util.Map;

public class BadGenericsTest extends BaseTest {

	private static Map<String, CKClassResult> report;

	@BeforeClass
	public static void setUp() {
		report = run(fixturesDir() + "/badgenerics");
	}

	// we can't really differentiate methods with same name and types that
	// only differ because of the generic type
	CKClassResult result = report.get("bg.BG");
	@Test
	public void exceptiontest() {
		
		//Assert.assertTrue(result.isError());
	assertTrue(result.getErrorMessage().contains("already visited"));
		//assertTrue(result.getErrorMessage().contains("Geberalready visited"));
	}
}
