package com.github.mauricioaniche.ck.metric;

import com.github.mauricioaniche.ck.ASTDebugger;
import com.github.mauricioaniche.ck.CKClassResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Arrays;
import java.util.Map;

public class NumberOfVariablesTest extends BaseTest {

	private static Map<String, CKClassResult> result;

	@BeforeClass
	public static void setUp() {
		result = run(fixturesDir() + "/variables");
	}
	
	@Test
	public void countmethodVarible()
	{
		CKClassResult  ckResult = result.get("variables.Variables");
	//	int actual=ckResult.getVariablesQty();

	       //Assert.assertEquals(9, actual);
		int expexted[]= new int[] {1,2,8,9,4};
		
		for(int i=2;i<5;i++) {
		Assert.assertEquals(0, ckResult.getMethod("m3/0").get().getVariablesQty());
		//Assert.assertEquals(expexted[i], ckResult.getMethod("m2/0").get().getVariablesQty());
		//Assert.assertEquals(expexted[i], ckResult.getMethod("m3/0").get().getVariablesQty());
		}
		
	}

/*	@Test
 	public void countVariavle() {
		CKClassResult  ckResult = result.get("variables.Variables");
		//Boundary valu analysis
		//BVC//min,min+,max-,max+,nominal
		/*int expexted[]= new int[] {0,1,99,100,9};
		
		
		 * 	for(int i=4;i<expexted.length;i++)
		{
		3333	 int actual=ckResult.getVariablesQty();

		       Assert.assertEquals(expexted[i], actual);
		}+
		
	//Robusrtneess	
	int expexted[]= new int[] {0,1,99,100,9,-1,101};
		
		for(int i=6;i<expexted.length;i++)
		{
			 int actual=ckResult.getVariablesQty();

		       Assert.assertEquals(expexted[i], actual);
		       System.out.println(" ######Invalid exceed input##########");
		}
		 
 

	}*/
}
