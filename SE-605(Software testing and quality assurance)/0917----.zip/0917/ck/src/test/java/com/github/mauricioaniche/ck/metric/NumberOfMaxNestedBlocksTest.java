package com.github.mauricioaniche.ck.metric;

import com.github.mauricioaniche.ck.CKClassResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.util.Map;

public class NumberOfMaxNestedBlocksTest extends BaseTest {

	private static Map<String, CKClassResult> report;

	@BeforeClass
	public static void setUp() {
		report = run(fixturesDir() + "/nestedblocks");
	}
	CKClassResult a = report.get("nestedblocks.NestedBlocks");
	@Test
	public void testMethodMaxNestedblock()
	{
		Assert.assertEquals(5, a.getMethod("m1/0").get().getMaxNestedBlocks());
		Assert.assertEquals(2, a.getMethod("m2/0").get().getMaxNestedBlocks());
	}
	/*
	@Test
	public void testMaxNestedblock() {
	
   int e=5;
		assertEquals(e, a.getMaxNestedBlocks());

	

	} */
}
