package com.github.mauricioaniche.ck.metric;

import com.github.mauricioaniche.ck.CKClassResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.util.Map;

public class NumberOfStringsTest extends BaseTest {

	private static Map<String, CKClassResult> report;

	@BeforeClass
	public static void setUp() {
		report = run(fixturesDir() + "/strings");
	}
	
	CKClassResult a = report.get("strings.Strings");
	@Test
	public void test_SringEach_MethodCount() {
		
		assertEquals(2, a.getMethod("m1/0").get().getStringLiteralsQty());
		assertEquals(3, a.getMethod("m2/0").get().getStringLiteralsQty());
		assertEquals(0, a.getMethod("m3/0").get().getStringLiteralsQty());
	}
	
	
	
	
	
	/*@Test
	public void test_SringCount() {
		

		assertEquals(1000, a.getStringLiteralsQty());
      
		

	}*/
}
