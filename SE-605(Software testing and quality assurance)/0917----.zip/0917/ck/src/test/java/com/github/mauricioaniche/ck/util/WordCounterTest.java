package com.github.mauricioaniche.ck.util;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Set;

public class WordCounterTest {
	
	 
	@Test
	public void containWordsInTest()
	{
		String sourceCode = "What is the hell";
		WordCounter wc=new WordCounter();

		Set<String> words = wc.wordsIn(sourceCode);
		assertTrue(words.contains("what"));
		assertTrue(words.contains("is"));
		assertTrue(words.contains("the"));
		assertTrue(words.contains("Hell")); 
		
	
	}
	
	/*@Test
	public void countWords() {
		String sourceCode = "a b cE GHS r$ a@ h^";
		WordCounter wc=new WordCounter();

		Set<String> words = wc.wordsIn(sourceCode);
		
		int expected=sourceCode.length();
		int actual=words.size();
		
		assertEquals(expected, actual);
	
			

	}
	
	@Test
	public void breakWordsTest() {
		String source = "A barking dogs Seldom_bites";
		Set<String> words = WordCounter.wordsIn(source);

	//	Assert.assertEquals(11, words.size());

		String[] expected = new String[] { "Barking", "dogs", "Seldom","bites","A"};
		for (String expectedString : expected) {
		
			Assert.assertTrue(words.contains(expectedString));
		}
	}


@Test
		public void ignoreJavaKeywords() {
			String sourceCode = "package a.b.c;\n" +
					"class Test {\n" +
					"@Tests public void metodo() {\n" +
					"  int taxes = 10;\n" +
					"  double interests = 0;"+
					"\n} }";

			Set<String> words = WordCounter.wordsIn(sourceCode);
		//	Assert.assertEquals(4, words.size());
			
			Assert.assertTrue(words.contains("Test"));
			Assert.assertTrue(words.contains("metodo"));
			Assert.assertTrue(words.contains("taxes"));
			Assert.assertTrue(words.contains("interests"));

		}

	*/
}
	


	

