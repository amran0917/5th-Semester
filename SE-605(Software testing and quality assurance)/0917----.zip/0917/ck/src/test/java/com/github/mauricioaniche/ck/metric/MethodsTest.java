package com.github.mauricioaniche.ck.metric;

import com.github.mauricioaniche.ck.CKClassResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.util.Map;

public class MethodsTest extends BaseTest {

	private static Map<String, CKClassResult> report;

	@BeforeClass
	public static void setUp() {
		report = run(fixturesDir() + "/methods");
	}
	CKClassResult  result = report.get("methods.Methods");
	
	

	 @Test
	 public void testPrivateMethod() {
		 
			int [] expected=new int[] {0,1,4,7,8,-1,9};
			
			for(int i=0;i<expected.length;i++) {
			 assertEquals(expected[6], result.getNumberOfPrivateMethods());
			}
	 }
	
	 

	 /*	@Test
	
	 * 

	 @Test
	 public void testProtectedMethod() {
		 
			int [] expected=new int[] {0,1,2,7,8,-1,9};
			
			for(int i=0;i<expected.length;i++) {
			 assertEquals(expected[i], result.getNumberOfProtectedMethods());
			}
	 }
	
	
public void testPublicMethodCount() {
	
		
		 
		int [] expected=new int[] {0,1,2,6,7,-1,8};
		
		for(int i=0;i<expected.length;i++) {
		 assertEquals(expected[i], result.getNumberOfPublicMethods());
		}
	}
 @Test
	 public void testStaticMethod() {
		 
			int [] expected=new int[] {0,1,3,6,7,-1,8};
			
			for(int i=0;i<expected.length;i++) {
			 assertEquals(expected[2], result.getNumberOfStaticMethods());
			}
	 }
	
	
	
	 
	@Test
	public void totalMethodTest() {
		
		int [] expected=new int[] {7,8,100,99,101,-1,0};
		
		for(int i=0;i<expected.length;i++) {
		Assert.assertEquals(expected[i], result.getNumberOfMethods());
		}
	}

	
	
	
	 * 
	 * 
	 */

	
}
