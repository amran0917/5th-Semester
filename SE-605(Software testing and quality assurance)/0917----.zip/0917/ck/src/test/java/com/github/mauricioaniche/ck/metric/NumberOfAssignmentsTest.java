package com.github.mauricioaniche.ck.metric;

import com.github.mauricioaniche.ck.CKClassResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.util.Map;

public class NumberOfAssignmentsTest extends BaseTest {

	private static Map<String, CKClassResult> report;

	@BeforeClass
	public static void setUp() {
		report = run(fixturesDir() + "/assignments");
	} 

	@Test
	public void counttotalNumberofAssigns() {
		CKClassResult a = report.get("assignments.Assignments");

		assertEquals(8, a.getAssignmentsQty());

		

	}
	
	
	
	
	
	
	
	/*
	 * 
	 * assertEquals(5, a.getMethod("m1/0").get().getAssignmentsQty());
		assertEquals(3, a.getMethod("m2/0").get().getAssignmentsQty());
		assertEquals(0, a.getMethod("m3/0").get().getAssignmentsQty());
	 */
}
