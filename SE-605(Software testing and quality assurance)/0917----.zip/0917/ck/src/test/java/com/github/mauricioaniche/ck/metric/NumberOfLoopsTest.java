package com.github.mauricioaniche.ck.metric;

import com.github.mauricioaniche.ck.CKClassResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Map;

public class NumberOfLoopsTest extends BaseTest {

	private static Map<String, CKClassResult> report;

	@BeforeClass
	public static void setUp() {
		report = run(fixturesDir() + "/loop");
	}
	
	CKClassResult ak = report.get("loop.Loop");

	
	
	@Test
public void count_forLoop() {
		
		int expectd =2;
		int actual=ak.getMethod("m1/0").get().getLoopQty();
		Assert.assertEquals(expectd, actual);
		
	}	
	
	/*@Test
	public void count_Total_NUmberofLoopTest() {
		
		int [] expected= new int[] {0,1,6,99,100,101,-1};
		
		for(int i=0;i<expected.length;i++)
		{
		
				Assert.assertEquals(expected[i], ak.getLoopQty());
				
		}

			
	} 
	
	@Test	
	public void count_forEach(){
	//	Loop lopo=new Loop();
	//		int expectd =lopo.countdo;
		    int expected=1;
			int actual=ak.getMethod("m5/0").get().getLoopQty();
			Assert.assertEquals(expected, actual);
	}
	
	*
		
		
	*
	*	
@Test	
public void count_whileLoop(){
		int expectd =2;
		int actual=ak.getMethod("m2/0").get().getLoopQty();
		Assert.assertEquals(expectd, actual);
}


	
	*
	*
	@Test	
	public void count_do_whileLoop(){
		Loop lopo=new Loop();
			int expectd =lopo.countdo;
			int actual=ak.getMethod("m3/0").get().getLoopQty();
			Assert.assertEquals(expectd, actual);
	}
	*
	*/
	

	
		

	
}
