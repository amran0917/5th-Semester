package com.github.mauricioaniche.ck.metric;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.github.mauricioaniche.ck.CKClassResult;

import static org.junit.Assert.assertEquals;

import java.util.Map;

public class FieldsTest extends BaseTest {

	private static Map<String, CKClassResult> report;

	@BeforeClass
	public static void setUp() {
		report = run(fixturesDir() + "/fields");
	}

	CKClassResult a = report.get("fields.Fields");

	@Test
	public void testallStaticfield() {

		assertEquals(2, a.getNumberOfStaticFields());
	}

	/*
	 * 
	 * /*@Test public void testAllNumberaofFields() {
	 * 
	 * Assert.assertEquals(5, a.getNumberOfFields()); }
	 * 
	 * 
	 * @Test public void allPublic() { System.out.println("Number of fields");
	 * assertEquals(2, a.getNumberOfPublicFields()); }
	 * 
	 * 
	 */
}
