package com.github.mauricioaniche.ck.metric;

import com.github.mauricioaniche.ck.CKClassResult;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.util.Map;

public class LOCTest extends BaseTest {

	private static Map<String, CKClassResult> report;

	@BeforeClass
	public static void setUp() {
		report = run(fixturesDir() + "/cbo");
	}
	
	CKClassResult a = report.get("cbo.Coupling1");
	@Test
	public void  testcountLinesIgnoringEmptyLines() {
		 int exp=11;;
		assertEquals(exp, a.getLoc());
	}
	
}
