mvn clean -Dmaven.javadoc.skip=true -DskipTests -Darguments=-DskipTests release:prepare release:perform
