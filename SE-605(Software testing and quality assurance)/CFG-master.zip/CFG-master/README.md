# CFG
#This makes a control flow graph matrix of a code containing if, else if, else, while, for, do-while of c,c++, java program
#After creating graph and matrix it shows the each indenpendent path 
#it shows the cyclomatic complexity of the code
