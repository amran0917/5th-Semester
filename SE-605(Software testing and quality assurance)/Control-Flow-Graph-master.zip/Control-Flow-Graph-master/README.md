# Control-Flow-Graph
In computer science, a control flow graph (CFG) is the graphical representation of control flow or computation during the execution of programs or applications. In this project I am reading java code and making control flow graph for all function from the given java code.
